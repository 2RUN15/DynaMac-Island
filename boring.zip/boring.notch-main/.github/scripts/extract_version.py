#!/usr/bin/env python3

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from argparse import ArgumentParser


SEMVER_RE = re.compile(r"v?[0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?")
NUMERIC_IDENTIFIER = r"(?:0|[1-9][0-9]*)"
ALPHANUMERIC_IDENTIFIER = r"(?:[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
PRERELEASE_IDENTIFIER = rf"(?:{NUMERIC_IDENTIFIER}|{ALPHANUMERIC_IDENTIFIER})"
BUILD_IDENTIFIER = r"(?:[0-9A-Za-z-]+)"
NORMALIZED_SEMVER_RE = re.compile(
    rf"^({NUMERIC_IDENTIFIER})\.({NUMERIC_IDENTIFIER})\.({NUMERIC_IDENTIFIER})"
    rf"(?:-({PRERELEASE_IDENTIFIER}(?:\.{PRERELEASE_IDENTIFIER})*))?"
    rf"(?:\+({BUILD_IDENTIFIER}(?:\.{BUILD_IDENTIFIER})*))?$"
)


def find_first_valid(text: str):
    for cand in SEMVER_RE.findall(text or ""):
        s = cand.lstrip("v")
        # Normalize for parsing: 2.7 -> 2.7.0, 2.7-beta -> 2.7.0-beta
        # Regex: look for X.Y at start, not followed by .Z
        normalized = re.sub(r"^([0-9]+\.[0-9]+)(?![0-9]*\.)", r"\1.0", s)
        parsed = NORMALIZED_SEMVER_RE.fullmatch(normalized)
        if parsed:
            return s, parsed
    return None, None


def write_github_output(version: str | None, is_beta_flag: bool) -> None:
    out = os.environ.get("GITHUB_OUTPUT")
    if not out:
        return
    try:
        with open(out, "a", encoding="utf-8") as f:
            f.write(f"version={version or ''}\n")
            f.write(f"is_beta={str(is_beta_flag).lower()}\n")
    except Exception:
        pass


def main(argv=None) -> int:
    p = ArgumentParser()
    p.add_argument("-c", "--comment", help="Comment body to scan (defaults: $COMMENT or stdin)")
    args = p.parse_args(argv)

    comment = args.comment or os.environ.get("COMMENT")
    if not comment:
        comment = sys.stdin.read() or ""

    version, parsed = find_first_valid(comment)

    beta = bool(parsed and parsed.group(4))

    # Write GitHub Actions outputs if available (GITHUB_OUTPUT)
    write_github_output(version, bool(beta))

    # For CLI consumption print simple key=value lines (and a human line)
    print(f"version={version or ''}")
    print(f"is_beta={str(bool(beta)).lower()}")
    print(f"Found version: {version} (beta: {bool(beta)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
